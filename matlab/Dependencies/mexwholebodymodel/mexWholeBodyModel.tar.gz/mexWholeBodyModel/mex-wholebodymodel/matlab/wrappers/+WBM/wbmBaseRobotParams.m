classdef wbmBaseRobotParams
    properties
        model@WBM.wbmBaseRobotModel
        config@WBM.wbmBaseRobotConfig
        wf2fixLnk@logical scalar
    end
end
