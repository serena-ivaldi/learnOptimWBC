classdef wbmFltgBaseState
    properties
        wf_R_b@double matrix
        wf_p_b@double vector
        v_b@double    vector
    end
end
