classdef wbmSimEnvironment
    properties
        background_color_opt@char
        ground_shape@double matrix
        ground_color
        ground_edge_color
        origin_pt_color
        origin_pt_size@double scalar
    end
end
