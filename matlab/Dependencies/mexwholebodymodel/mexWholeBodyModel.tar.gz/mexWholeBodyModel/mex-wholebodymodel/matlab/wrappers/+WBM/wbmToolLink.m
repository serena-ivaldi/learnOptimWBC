classdef wbmToolLink
    properties
        urdf_link_name@char
        ee_vqT_tt@double vector
    end
end
