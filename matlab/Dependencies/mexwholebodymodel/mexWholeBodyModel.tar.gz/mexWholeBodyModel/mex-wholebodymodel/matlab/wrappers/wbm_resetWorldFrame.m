function wbm_resetWorldFrame()
    % WBM_MODELINITIALIZE initializes the whole body model of the robot.
    %
    %   INPUT ARGUMENTS:
    %       Optimized mode:  
    %                  no optimized mode
    %
    %       Normal mode:
    %                  no arguments
    %
    %       method that has to be call when many experiments are performed
    %       on the same icub
    %
    %   OUTPUT ARGUMENTS:  none
    %
    % Author: Valerio Modugno (modugno@uniroma1.it); Roma, apr 2017
   
    mexWholeBodyModel('reset-world-frame');
        
end
