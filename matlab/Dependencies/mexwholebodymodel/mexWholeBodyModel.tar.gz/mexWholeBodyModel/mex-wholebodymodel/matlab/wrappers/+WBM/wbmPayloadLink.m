classdef wbmPayloadLink
    properties
        urdf_link_name@char
        pt_mass@double   scalar
        lnk_p_pl@double vector
    end
end
