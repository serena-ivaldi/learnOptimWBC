function clearExit(code_num)
    clear mexWholeBodyModel; % remove the subroutine from the system memory ...
    exit(code_num);
end
